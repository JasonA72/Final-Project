﻿using UnityEngine;
using System.Collections;

public class Jump : MonoBehaviour
{

	public Rigidbody rb;
	public bool isGrounded = false;

	void Update ()
	{

		if (Input.GetKey (KeyCode.Space) && isGrounded == true) {
			rb.AddForce (Vector3.up * 200);

		}
	}
}
