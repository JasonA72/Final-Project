﻿using UnityEngine;
using System.Collections;

public class NetworkManager : MonoBehaviour
{

	public Camera mapCamera;
	SpawnPlayers[] spawnSpots;

	void Start ()
	{
		spawnSpots = GameObject.FindObjectsOfType<SpawnPlayers> ();
		Connect ();
	}


	void Connect ()
	{
		PhotonNetwork.autoJoinLobby = true;
		PhotonNetwork.ConnectUsingSettings ("0.7");


	}

	void OnGUI ()
	{
		GUILayout.Label (PhotonNetwork.connectionStateDetailed.ToString ());
	}

	void OnJoinedLobby ()
	{
		PhotonNetwork.JoinRandomRoom ();
	}

	void OnPhotonRandomJoinFailed ()
	{
		PhotonNetwork.CreateRoom (null);
	}

	void OnJoinedRoom ()
	{
		SpawnMyPlayer ();
	}

	void SpawnMyPlayer ()
	{
		if (spawnSpots == null) {
			Debug.LogError ("No Spawns");
			return;
		}

		SpawnPlayers mySpawn = spawnSpots [Random.Range (0, spawnSpots.Length)];

		GameObject myPlayer = (GameObject)PhotonNetwork.Instantiate ("Player", mySpawn.transform.position, mySpawn.transform.rotation, 0);
		mapCamera.enabled = false;


		myPlayer.GetComponent<MoveCamera> ().enabled = true;
		myPlayer.GetComponent<Grounded> ().enabled = true;
		myPlayer.transform.FindChild ("Main Camera").gameObject.SetActive (true);
		//myPlayer.GetComponent<Jump> ().enabled = true;
		myPlayer.GetComponentInChildren<Pause> ().enabled = true;


	}
}
