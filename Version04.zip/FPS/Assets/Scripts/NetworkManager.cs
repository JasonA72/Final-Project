﻿using UnityEngine;
using System.Collections;

public class NetworkManager : MonoBehaviour
{

	public Camera mapCamera;


	void Start ()
	{
		Connect ();
	}


	void Connect ()
	{
		PhotonNetwork.autoJoinLobby = true;
		PhotonNetwork.ConnectUsingSettings ("0.4");


	}

	void OnGUI ()
	{
		GUILayout.Label (PhotonNetwork.connectionStateDetailed.ToString ());
	}

	void OnJoinedLobby ()
	{
		Debug.Log ("TRIED");
		PhotonNetwork.JoinRandomRoom ();
	}

	void OnPhotonRandomJoinFailed ()
	{
		Debug.Log ("FAILED");
		PhotonNetwork.CreateRoom (null);
	}

	void OnJoinedRoom ()
	{
		SpawnMyPlayer ();
	}

	void SpawnMyPlayer ()
	{
		GameObject myPlayer = (GameObject)PhotonNetwork.Instantiate ("Player", (new Vector3 (250, 10, 250)), Quaternion.identity, 0);
		mapCamera.enabled = false;


		myPlayer.GetComponent<MoveCamera> ().enabled = true;
		myPlayer.GetComponent<Grounded> ().enabled = true;
		myPlayer.transform.FindChild ("Main Camera").gameObject.SetActive (true);
		//myPlayer.GetComponent<Jump> ().enabled = true;
		myPlayer.GetComponentInChildren<Pause> ().enabled = true;


	}
}
