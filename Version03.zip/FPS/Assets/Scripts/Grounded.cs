﻿using UnityEngine;
using System.Collections;

public class Grounded : MonoBehaviour
{

	public GameObject player;
	RaycastHit hit;
	public Jump ground;

	void Update ()
	{
		Vector3 pos = transform.position;

		if (Input.GetKey (KeyCode.Space)) {

			print ("SPACE");

			if (Physics.Raycast (transform.position, transform.TransformDirection (new Vector3 (0, -1, 0)), 1.1f)) {
				ground.isGrounded = true;
				print ("GROUND");
			} else {
				ground.isGrounded = false;
			}



			/*

			Ray ray = 
				
			if (Physics.Raycast (, out hit)) {
				if (hit.collider != null) {
					Vector3 ground = hit.point;
				}
			}

			transform.position = pos;
		}
*/
		}
	
	}
}
