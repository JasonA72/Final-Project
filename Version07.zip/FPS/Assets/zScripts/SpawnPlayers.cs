﻿using UnityEngine;
using System.Collections;

public class SpawnPlayers : MonoBehaviour
{

	public int teamId = 0;

}
