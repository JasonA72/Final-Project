﻿using UnityEngine;
using System.Collections;

public class Crosshair : MonoBehaviour
{

	public Texture crosshair;


	void OnGUI ()
	{
	
		GUI.DrawTexture (new Rect (Screen.width / 2 - 10, Screen.height / 2 - 10, 20, 20), crosshair, ScaleMode.ScaleAndCrop);

	}
}
