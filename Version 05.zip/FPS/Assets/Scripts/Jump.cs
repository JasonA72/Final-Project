﻿using UnityEngine;
using System.Collections;

public class Jump : MonoBehaviour
{

	public Rigidbody rb;
	public bool isGrounded = false;

	float vVelocity = 20;

	void Update ()
	{

		if (Input.GetKeyDown (KeyCode.Space)) {
			Debug.Log ("Jump");
			vVelocity += Physics.gravity.y * Time.deltaTime;

			Vector3 verticalVelocity = new Vector3 (0, vVelocity, 0);

			transform.position += verticalVelocity;


		}
	}
}
